# No third-party libraries; the offline game is packaged as one local HTML asset.
