# Архитектура проекта

- `app/src/main/assets/index.html` — разметка игрового экрана.
- `app/src/main/assets/css/game.css` — стили интерфейса и мобильных оверлеев.
- `app/src/main/assets/js/game.js` — Canvas-игровой цикл, игровой контент и локальные сохранения (`localStorage`).
- `app/src/main/java/com/lumen/beacon/MainActivity.java` — минимальная нативная оболочка `WebView`, полноэкранная портретная ориентация и обработка жизненного цикла.
- `app/src/main/AndroidManifest.xml` — минимальная конфигурация без разрешения `INTERNET`.
- `app/build.gradle` — Android Gradle Plugin, application ID `com.lumen.beacon`, minSdk 23, targetSdk 28.
- `.github/workflows/build-apk.yml` — сборка на GitHub-hosted runner, статическая проверка, `assembleDebug`, проверка архива/подписи и артефакт APK.
- `tools/verify_project.py` — повторяемая проверка JavaScript, игровых систем и структуры Android-проекта.
- `docs/source-prototype-v3.3-A1.html` — неизменённая исходная версия, сохранённая для сравнения и отката.

Оболочка не загружает код из сети, не использует сторонние библиотеки и не внедряет мост JavaScript↔Java.
