# QA Status — 2026-10-25

**Passed locally:** JavaScript syntax check, static feature markers, project-layout checks, offline manifest check, 10,000 Monte Carlo samples through the actual lampad-drop function.

**Not run here:** Android Gradle build/signing (Android SDK and Gradle are absent in this container); visual Chromium smoke test (Chromium failed to exit even with a minimal/original HTML page). The GitHub Actions workflow performs the real APK build and signing verification. No APK is claimed to be built yet.

**Device QA required:** installation on Android, persistence, audio/lifecycle, and performance at high enemy counts.
