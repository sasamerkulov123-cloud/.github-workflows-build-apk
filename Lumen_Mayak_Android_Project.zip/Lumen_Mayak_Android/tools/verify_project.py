#!/usr/bin/env python3
"""Static source and syntax checks for Lumen: Маяк Android package."""
from pathlib import Path
import re, subprocess, tempfile, sys, zipfile, json, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'app/src/main/assets/index.html'
JS = ROOT / 'app/src/main/assets/js/game.js'
CSS = ROOT / 'app/src/main/assets/css/game.css'
if not HTML.exists() or not JS.exists() or not CSS.exists():
    raise SystemExit('FAIL: expected HTML/CSS/JS game asset is missing')
h = HTML.read_text(encoding='utf-8'); s = JS.read_text(encoding='utf-8')
REQUIRED = [
    'LUMEN_BUILD', 'lumenDamageLampad', 'LUMEN_ELITE', 'lumenChooseAltar',
    'RESONANCES', 'Звёздная пыль', 'Громовой молот', 'Вихрь клинков',
    'Священная зола', 'Нить рассвета', 'Стая огоньков', 'Линза', 'Плащ',
    'Талисман', 'Эхо-камень', 'Кодекс Маяка', 'window.lumenBack=function',
    'e.hp*=P.hunger||1', 'lumenRandDrop(luck=0)', 'nextAltarAt=180', 'LAMPADS.some(l=>(l.x-e.x)**2+(l.y-e.y)**2<42*42)', 'e._eliteRewarded=true', 'if(e.hp<=0)continue', 'runResonances={}', 'life:90'
]
missing=[x for x in REQUIRED if x not in s]
if missing: raise SystemExit('FAIL: expected game feature(s) missing: '+', '.join(missing))
if 'href="css/game.css"' not in h or 'src="js/game.js"' not in h:
    raise SystemExit('FAIL: HTML does not reference separated local CSS/JS assets')
r=subprocess.run(['node','--check',str(JS)],capture_output=True,text=True)
if r.returncode: raise SystemExit('FAIL: JavaScript syntax error:\n'+r.stderr)
# Test the actual in-game drop function (not a second copy of its probability formula).
fnm=re.search(r'function lumenRandDrop\(luck=0\)\s*\{.*?\n\}', s, re.S)
if not fnm: raise SystemExit('FAIL: lampad drop function missing')
node_test = r"""
const rnd=Math.random;
__DROP_FUNCTION__
const counts={gold:0,oil:0,magnet:0,bomb:0,empty:0};
for(let i=0;i<10000;i++)counts[lumenRandDrop(0)]++;
const expected={gold:.40,oil:.25,magnet:.15,bomb:.10,empty:.10};
for(const [k,p] of Object.entries(expected)){const actual=counts[k]/10000;if(Math.abs(actual-p)>.03)throw new Error(`drop probability out of tolerance for ${k}: ${actual}`)}
console.log('PASS_DROP',JSON.stringify(counts));
""".replace('__DROP_FUNCTION__',fnm.group(0))
with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'drop-test.js';p.write_text(node_test,encoding='utf-8')
    r=subprocess.run(['node',str(p)],capture_output=True,text=True)
    if r.returncode: raise SystemExit('FAIL: actual lampad drop distribution test:\n'+r.stderr)
for rel in ['settings.gradle','build.gradle','gradle.properties','CHANGELOG.md','app/build.gradle','app/src/main/AndroidManifest.xml','app/src/main/java/com/lumen/beacon/MainActivity.java','app/src/main/res/values/styles.xml','app/src/main/res/drawable/ic_launcher.xml','.github/workflows/build-apk.yml']:
    if not (ROOT/rel).exists(): raise SystemExit('FAIL: project file missing: '+rel)
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android.permission.INTERNET' in manifest: raise SystemExit('FAIL: this offline game should not request internet permission')
if 'android:name=".MainActivity"' not in manifest or 'android.intent.action.MAIN' not in manifest:
    raise SystemExit('FAIL: Android launcher activity is missing')
activity=(ROOT/'app/src/main/java/com/lumen/beacon/MainActivity.java').read_text(encoding='utf-8')
for marker in ['setJavaScriptEnabled(true)','setDomStorageEnabled(true)','setAllowFileAccessFromFileURLs(true)','setAllowUniversalAccessFromFileURLs(false)','window.lumenBack']:
    if marker not in activity: raise SystemExit('FAIL: Android WebView configuration missing: '+marker)
wf=(ROOT/'.github/workflows/build-apk.yml').read_text(encoding='utf-8')
for marker in ['assembleDebug','APKSIGNER=','verify --verbose','upload-artifact@v4','workflow_dispatch']:
    if marker not in wf: raise SystemExit('FAIL: GitHub Actions workflow missing: '+marker)
for rel in ['app/src/main/assets/css/game.css','app/src/main/assets/js/game.js']:
    if not (ROOT/rel).is_file(): raise SystemExit('FAIL: local game asset missing: '+rel)
if re.search(r'(?:src|href)=["\']https?://', h): raise SystemExit('FAIL: external online asset reference found in HTML')
for ref in re.findall(r'(?:src|href)=["\']([^"\']+)["\']', h):
    if not ref.startswith(('http://','https://','data:','#')) and not (ROOT/'app/src/main/assets'/ref).is_file():
        raise SystemExit('FAIL: local HTML asset cannot be found: '+ref)
for rel in ['app/src/main/AndroidManifest.xml','app/src/main/res/values/styles.xml','app/src/main/res/drawable/ic_launcher.xml']:
    try: ET.parse(ROOT/rel)
    except ET.ParseError as exc: raise SystemExit('FAIL: invalid Android XML in '+rel+': '+str(exc))
app_gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
for marker in ['compileSdk 35','minSdk 23',"applicationId 'com.lumen.beacon'"]:
    if marker not in app_gradle: raise SystemExit('FAIL: Android Gradle configuration missing: '+marker)
print('PASS: JS syntax, local HTML asset paths, gameplay systems, launcher/manifest/resources, offline WebView configuration, Gradle settings, GitHub APK workflow, and 10,000 lampad drop samples.')
